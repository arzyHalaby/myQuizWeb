import React from 'react';
// Styles
import { Grid } from './App.styles';

const App = () => {
  return (
    <div>
      <Grid>Start Here!</Grid>
    </div>
  );
};

export default App;
